﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para CriarCliente.xaml
    /// </summary>
    public partial class CriarCliente : Window
    {
        public CriarCliente()
        {
            InitializeComponent();
        }

        private void volta_Click(object sender, RoutedEventArgs e)
        {
            MainWindow  m   = new MainWindow();
            m.Show();
            this.Close();
        }

        private void cadastrarCliente_Click(object sender, RoutedEventArgs e)
        {
            // 1. Define a mensagem de sucesso ou processamento
            string mensagem = "Cliente Cadastrado com Sucesso!";

            // 2. Acessa a Label usando o x:Name definido no XAML e atualiza a propriedade Content
            statusCadastroCliente.Content = mensagem;

            // Opcional: Você pode querer mudar a cor do texto para indicar sucesso:
            statusCadastroCliente.Foreground = Brushes.Green;
        }
    }
}
