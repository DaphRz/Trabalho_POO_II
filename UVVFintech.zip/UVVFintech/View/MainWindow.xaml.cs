﻿using Google.Api.Ads.AdWords.v201809;
using Microsoft.Data.SqlClient;
using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UVVFintech.View;

namespace UVVFintech.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection conexao = null;

        public MainWindow()
        {
            InitializeComponent();

            string URL = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = BancoDoBanco; Integrated Security = True; Connect Timeout = 30; Encrypt = False; Trust Server Certificate = False; Application Intent = ReadWrite; Multi Subnet Failover = False";

            try
            {
                conexao = new SqlConnection(URL);
                conexao.Open();
                statusBD.Foreground = new SolidColorBrush(Colors.Green);
                statusBD.Content = "Conexão com o Banco de Dados OK!";
            }
            catch (Exception e)
            {
                statusBD.Foreground= new SolidColorBrush(Colors.Red);
                statusBD.Content = $"Erro ao conectar com o Banco de Dados: {e.Message}";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpcaoDeConta opc = new OpcaoDeConta();
            opc.Show();
            this.Close();
        }

        private void cria_Click(object sender, RoutedEventArgs e)
        {
            CriarCliente cliente = new CriarCliente();
            cliente.Show();
            this.Close();
        }

        private void buscaCo_Click(object sender, RoutedEventArgs e)
        {
            Busca busca = new Busca();
            busca.Show();
            this.Close();
        }
    }
}