﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para TodasContas.xaml
    /// </summary>
    public partial class TodasContas : Window
    {
        public TodasContas()
        {
            InitializeComponent();
        }
        private void volta_Click(object sender, RoutedEventArgs e)
        {
            Busca busca = new Busca();
            busca.Show();
            this.Close();
        }
    }
}
