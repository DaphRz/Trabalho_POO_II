﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{

    internal class Deposito : Transacoes
    {
       public decimal valor { get; set; }
        public int idTransacao { get; set; }
       public DateTime dataTransacao { get; set; }

       public Conta conta { get; set; }
        public Deposito(decimal valor, DateTime data, int idTransacao, Conta conta) 
        {
            this.valor = valor;
            this.dataTransacao = data;
            this.idTransacao = idTransacao;
            this.conta = conta;
        }
        
    }
}
