﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    public class ContaCorrente : Conta
    {
        public decimal taxaManutencao { get; set; }

        public ContaCorrente(string NumeroConta, Cliente titular, decimal Saldo): base (NumeroConta, titular, Saldo)
        {

        }
       
    }
}
