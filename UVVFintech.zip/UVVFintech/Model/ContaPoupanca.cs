﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    public class ContaPoupanca : Conta
    {
        public decimal TaxaRendimento { get; set; }

        public ContaPoupanca(string NumeroConta, Cliente titular, decimal Saldo) : base(NumeroConta, titular, Saldo)
        {
        }

        // Aplica rendimento à conta e retorna o valor do rendimento aplicado
        public decimal AplicarRendimentoMensal(bool taxaAnual = false, int casasDecimais = 2)
        {
            decimal taxa = TaxaRendimento;
            if (taxaAnual)
                taxa = taxa / 12m;

            var rendimento = Math.Round(Saldo * taxa, casasDecimais, MidpointRounding.AwayFromZero);
            Saldo += rendimento;
            return rendimento;
        }
    }
}