﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    internal interface Transacoes
    {
        public  decimal valor { get; set; }
        public  int idTransacao { get; set; }   
        public  DateTime dataTransacao { get; set; }
        public  Conta conta { get; set; }

       

    }
}