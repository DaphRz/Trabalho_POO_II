﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    public abstract class Conta
    {
        public string NumeroConta { get; set; }

        public Cliente Titular { get; set; }

        public decimal Saldo { get; set; }

        public Conta(string numeroConta, Cliente titular, decimal Saldo)
        {
            NumeroConta = numeroConta;
            Titular = titular;
            this.Saldo = Saldo;

        }

        public virtual void Depositar(decimal valor)
        {
            if (valor <= 0)
                throw new ArgumentException("Valor inválido.");

            Saldo += valor;
        }

        public virtual void Sacar(decimal valor)
        {
            if (valor <= 0)
                throw new ArgumentException("Valor inválido.");

            Saldo -= valor;
        }

        public virtual void Pagamento(decimal valor, Conta recebedor)
        {
            if (recebedor == null)
                throw new ArgumentNullException(nameof(recebedor));

            this.Sacar(valor);
            recebedor.Depositar(valor);
        }

    }
}