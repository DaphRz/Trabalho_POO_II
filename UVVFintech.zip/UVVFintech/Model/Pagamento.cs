﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    internal class Pagamento:Transacoes
    {
        public decimal valor { get; set; }
        public int idTransacao { get; set; }
        public DateTime dataTransacao { get; set; }

        public Conta conta { get; set; }
        public Conta recebedor { get; set; }
        public Pagamento(decimal valor, DateTime data, int idTransacao, Conta conta, Conta recebedor)
        {
            this.valor = valor;
            this.dataTransacao = data;
            this.idTransacao = idTransacao;
            this.conta = conta;
            this.recebedor = recebedor;
        }
    }
}
