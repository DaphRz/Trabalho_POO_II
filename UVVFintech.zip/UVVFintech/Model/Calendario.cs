﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    public class Calendario
    {
        public DateTime DataAtual { get; private set; }

        public Calendario()
        {
            DataAtual = DateTime.Today;
        }

        public Calendario(DateTime dataInicial)
        {
            DataAtual = dataInicial;
        }

        public void AvancarDias(int dias)
        {
            DataAtual = DataAtual.AddDays(dias);
        }

        public void AvancarMes(int meses)
        {
            DataAtual = DataAtual.AddMonths(meses);
        }

        public void AvancarAno(int anos)
        {
            DataAtual = DataAtual.AddYears(anos);
        }

        public bool EhFimDeSemana()
        {
            return DataAtual.DayOfWeek == DayOfWeek.Saturday ||
                   DataAtual.DayOfWeek == DayOfWeek.Sunday;
        }

        public List<DateTime> ObterDiasDoMes()
        {
            var dias = new List<DateTime>();

            int diasNoMes = DateTime.DaysInMonth(DataAtual.Year, DataAtual.Month);

            for (int dia = 1; dia <= diasNoMes; dia++)
            {
                dias.Add(new DateTime(DataAtual.Year, DataAtual.Month, dia));
            }

            return dias;
        }

        // Aplica rendimento mensal a uma conta (retorna rendimento aplicado)
        public decimal AplicarRendimentoMensal(ContaPoupanca conta, bool taxaAnual = false, int casasDecimais = 2)
        {
            if (conta == null) throw new ArgumentNullException(nameof(conta));
            return conta.AplicarRendimentoMensal(taxaAnual, casasDecimais);
        }
    }
}